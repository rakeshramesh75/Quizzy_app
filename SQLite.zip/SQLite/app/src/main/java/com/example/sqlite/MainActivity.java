package com.example.sqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
EditText e1,e2;
TextView t1;
controller db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.edit1);
        e2=findViewById(R.id.edit2);
        t1=findViewById(R.id.txt);
    }
    public void onbutton(View view){
        switch(view.getId())
        {
            case R.id.btn1:
                db.insert(e1.getText().toString(),e2.getText().toString());
                break;
            case R.id.btn2:
                db.delete(e1.getText().toString());
                break;
            case R.id.btn3:
                AlertDialog.Builder dialog=new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("Enter Firstname");
                final EditText newframe=new EditText(this);
                dialog.setView(newframe);
                dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        db.update(e1.getText().toString(),newframe.getText().toString());
                    }
                });
                dialog.show();
                break;
            case R.id.btn4:
                db.list(t1);
                break;
        }
    }
}